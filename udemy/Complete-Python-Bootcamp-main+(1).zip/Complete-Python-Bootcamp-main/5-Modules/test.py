from package.maths import *
from package.subpackages.mult import multiply

print(addition(2,3))
print(substraction(4,3))
print(multiply(4,5))